package com.example.continent_explorer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContinentExplorerApplicationTests {

    @Test
    void contextLoads() {
    }

}
